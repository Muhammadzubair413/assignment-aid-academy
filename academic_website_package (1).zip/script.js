// Dynamic greeting based on time of day
window.addEventListener('DOMContentLoaded', () => {
    const greetingContainer = document.createElement('p');
    const hour = new Date().getHours();
    let greetingText = "Welcome!";

    if (hour < 12) {
        greetingText = "Good Morning! Welcome to Expert Academic Solutions.";
    } else if (hour < 18) {
        greetingText = "Good Afternoon! Welcome to Expert Academic Solutions.";
    } else {
        greetingText = "Good Evening! Welcome to Expert Academic Solutions.";
    }

    greetingContainer.textContent = greetingText;
    greetingContainer.style.textAlign = 'center';
    greetingContainer.style.marginTop = '20px';
    greetingContainer.style.fontSize = '1.2rem';
    greetingContainer.style.color = '#004080';
    document.body.insertBefore(greetingContainer, document.body.firstChild);
});

// WhatsApp Click-to-Chat Function
function openWhatsApp() {
    const phoneNumber = "+923035322447";
    const message = encodeURIComponent("Hello! I'm interested in your academic assistance services.");
    const url = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(url, '_blank');
}

// Example form validation (optional for future use)
function validateForm() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();

    if (!name || !email || !message) {
        alert("Please fill out all fields.");
        return false;
    }
    alert("Message sent successfully!");
    return true;
}
